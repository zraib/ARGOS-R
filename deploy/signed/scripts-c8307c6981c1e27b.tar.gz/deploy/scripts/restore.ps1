﻿# ============================================================================
# ARGOS / IRIS — restauration d'une sauvegarde (PowerShell, Docker Desktop)
# Usage :  .\scripts\restore.ps1 -Stamp 20260914-103000 [-Source D:\sauvegardes\iris]
# ARRÊTE l'API le temps de remettre le volume, puis redémarre la pile.
# ============================================================================
param(
  [Parameter(Mandatory = $true)][string]$Stamp,
  [string]$Source = (Join-Path $PSScriptRoot "..\backups")
)

$ErrorActionPreference = "Stop"
# Sans `-f` : docker compose lit COMPOSE_FILE dans .env (HTTPS activé ou non — README § 11).
$deploy = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$dump = Join-Path $Source "db-$Stamp.sql.gz"
$tar  = Join-Path $Source "api-data-$Stamp.tar.gz"
if (-not (Test-Path $dump) -or -not (Test-Path $tar)) { throw "Sauvegarde $Stamp introuvable dans $Source" }

$env = Get-Content (Join-Path $PSScriptRoot "..\.env") | Where-Object { $_ -match "^\s*[A-Z_]+=" }
$dbUser = (($env | Where-Object { $_ -like "POSTGRES_USER=*" }) -split "=", 2)[1]; if (-not $dbUser) { $dbUser = "argos" }
$dbName = (($env | Where-Object { $_ -like "POSTGRES_DB=*" }) -split "=", 2)[1];   if (-not $dbName) { $dbName = "argos" }

Write-Host "Arrêt de l'API et du proxy"
docker compose --project-directory $deploy stop proxy api

Write-Host "1/2  Base PostgreSQL ← $dump"
Get-Content $dump -AsByteStream -Raw | docker run --rm -i alpine:3.20 gunzip -c | docker compose --project-directory $deploy exec -T db psql -U $dbUser -d $dbName -q
if ($LASTEXITCODE -ne 0) { throw "restauration PostgreSQL échouée" }

Write-Host "2/2  Volume de l'API ← $tar"
docker run --rm -v iris_api_data:/data -v "${Source}:/in:ro" alpine:3.20 sh -c "rm -rf /data/* && tar xzf /in/api-data-$Stamp.tar.gz -C /data"
if ($LASTEXITCODE -ne 0) { throw "restauration du volume api_data échouée" }

Write-Host "Redémarrage"
docker compose --project-directory $deploy up -d
Write-Host "Restauration $Stamp terminée."

# SIG # Begin signature block
# MIIIAAYJKoZIhvcNAQcCoIIH8TCCB+0CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB7M0a/yIiFtx+b
# O3i0f8keSAfp+zQX7c+QEtxyyrsQNKCCBIgwggSEMIIC7KADAgECAhQZkZL6AS29
# ZKT8EZ/67bkku/cubjANBgkqhkiG9w0BAQsFADBRMS0wKwYDVQQDDCRJUklTIFN0
# YXRpb24gLSBTaWduYXR1cmUgZGVzIHNjcmlwdHMxEzARBgNVBAoMCkFSR09TIFJE
# SUExCzAJBgNVBAYTAk1BMB4XDTI2MDkyMzEyMzgxN1oXDTM2MDkyMDEyMzgxN1ow
# UTEtMCsGA1UEAwwkSVJJUyBTdGF0aW9uIC0gU2lnbmF0dXJlIGRlcyBzY3JpcHRz
# MRMwEQYDVQQKDApBUkdPUyBSRElBMQswCQYDVQQGEwJNQTCCAaIwDQYJKoZIhvcN
# AQEBBQADggGPADCCAYoCggGBAK/tnaiuF/+Zp8YrShYI3zjt29xXDNA6kZzDjzP8
# +J3/TePVTg0r8zdRDjpJJP3M2Y8OK6qrv+P6bAQhlKu+8/GyQozhzc1MBL2ofg5F
# wj6R3G1lR/5knQsx3yg8fQO+ALhs4P6miSEoLYv117dntRoM/0dX1iwl18p4yLQn
# DFREkyuWpa8w9rAPkukcjWbUagC47He9O0Ge8bztZA1kQ610uNzKSfCQuiKrigfK
# Uzv+1CEBYW4FTG1X025zUJlxIcrHvw3csO06xYdhdpU5EzD2bd4m10ERP3fyN1cI
# 2uZwzzHcXolEaTlVrhR7OUv84UgXg69F5pvjg5iVNZXIa+KUipbIjP7/fGQh2EEy
# q1yN9eoabO8/A8cEFEKRpYurIVj3IUaDNAGqZidA2mLwkvMlW8QoMqtFYfIhqqD8
# c36ORhoAYGVFHT7r1Uze04qIWqzJtwqrKzwrx4pYJ1tQ3gZl+D+4jpnToEpdgVYd
# /+cYjOX6XWAcKyM2iOONuSRoaQIDAQABo1QwUjAMBgNVHRMBAf8EAjAAMA4GA1Ud
# DwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQU7GYdjyRk
# iy+ab2VKRGKrVEsHxaEwDQYJKoZIhvcNAQELBQADggGBADb3foUiOzMXmWawsIKF
# vnn0+Lp+XappmlS0VnQDPiuWx2ccclWAXuiCQlCIhh0tZXbBc5bhJ0P3BpeKZcPX
# ZBXSK8sGTHzDEIufRgqERY41vfpeonZ31N2yuiDUoN0beqjTs5BeQskmAM/wmeg8
# hoxSLRVMY04lM/MHmlr6zbgAQg+fU1lQAj7EWCQWwjrrVgJU6P5Jfw4SZTTAp5Cw
# j7Q+s87DzgJIvf2kr0D+RMynE7M7qJx53rXsLM2LR4A5EwIow4QfjWa2JH1SIsdy
# tWIyjouU9djojBhjCSDnYYiMWDU2+0mgTAeSx0qtNNp8W5Mw7RWaHx/q/h++WzzV
# UnIAb4bDRTugECpUu1APAC1EymM4/EcChi8icMyKg9uucgFEG8c+ECBQZDS0RewZ
# Z4QfZ9WNH/w942ho7bIOvlHEsL/h9cI6vcInVH1Z7qkTMYu/Gxa49G4WmQW3i62b
# GJRgoE9MmGMY0X9Tu6h12Q9sEZN13Lz6Tu/3JqFE4TrCgDGCAs4wggLKAgEBMGkw
# UTEtMCsGA1UEAwwkSVJJUyBTdGF0aW9uIC0gU2lnbmF0dXJlIGRlcyBzY3JpcHRz
# MRMwEQYDVQQKDApBUkdPUyBSRElBMQswCQYDVQQGEwJNQQIUGZGS+gEtvWSk/BGf
# +u25JLv3Lm4wDQYJYIZIAWUDBAIBBQCggbcwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYJKoZIhvcNAQkFMQ8XDTI2MDkyNDAwNDEzOVowHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwLQYKKwYBBAGCNwIBDDEfMB2gG4EZSVJJUyAtIHNj
# cmlwdHMgZGUgc3RhdGlvbjAvBgkqhkiG9w0BCQQxIgQgfdEryPiob+n+lRS4U/qn
# r1LED9DHqs7RYNVqO+2cL1YwDQYJKoZIhvcNAQEBBQAEggGAWCdqUEJA8otka5rt
# JNOzAFL9Z77pQXXJqkNY9UV7gV6i0kQQbSvJs5RrFT5LO3R0sfyXDdD8lJKMZuJJ
# ZQgliZd7xllL8+RbwSyUC6BedOhcJw502kwO/9s6hHdYqCc0gkkQ60kaBlOEQF0n
# lJxZETHfdAwKpg1bGJm0jsfZZcA+Fn4/QV/6BsT+X5IqkDBofUXIW9Fv6/1sWGRs
# OCxDQlvzzuofV72vdyx+1IAITYfV+wFTKdOisBISTmsr8ZPJIz0c7XbDgTBylxul
# GVoNCZhu9qG+MDbwEjEmtWE9FGvZbJ9x3GO6LRK7XusrSlUR1hi4dS62UkD1nPag
# q9VFCjGvd0mfY9q1z2P5jRqCgY185s+f/MnNYUHx2XMhOJ9Z1c0wGguzc1vVHFnd
# GKuS8/xXofngNQNpCAou+6pkysBuiyQDe5wAnS6b+XBIstX3TdO5st6iU9/Uc+xZ
# yw4Sfne7K9rcG7Fo5015oXWTmbsiu7xbyADk7NlBJuaIQwbU
# SIG # End signature block
