﻿# ============================================================================
# ARGOS / IRIS — approuver l'éditeur des scripts de la station (ADR 0031)
#
# Les scripts PowerShell du paquet sont signés (Authenticode) par le certificat
# « IRIS Station - Signature des scripts », livré dans deploy\certs\
# iris-signature.cer. Pour que Windows les exécute sans contournement — même
# extraits d'un zip téléchargé (« n'est pas signé numériquement ») —, ce
# certificat doit figurer parmi les Autorités de certification racines de
# confiance ET les Éditeurs approuvés. Ce script :
#   1. l'y ajoute, une fois : pour toute la machine en administrateur (sans
#      question), sinon pour l'utilisateur courant (Windows demande alors de
#      confirmer l'ajout : répondre Oui) ;
#   2. ne remplace JAMAIS en silence un certificat IRIS déjà approuvé par un
#      autre : un paquet signé par une autre clé est signalé (-Replace pour
#      assumer un changement de clé) ;
#   3. vérifie la signature de chaque script du paquet et dit ce qu'il en est.
# Appelé par install.cmd et upgrade.cmd ; relançable seul (trust.cmd). Il ne
# bloque rien : les lanceurs .cmd exécutent les scripts dans tous les cas.
#
#   .\trust.cmd [-Replace] [-NoPrompt]
# ============================================================================
param(
  [switch]$Replace,
  [switch]$NoPrompt
)
$ErrorActionPreference = "Stop"
$deploy = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$cerPath = Join-Path $deploy "certs\iris-signature.cer"

function Ok([string]$msg) { Write-Host "    OK  $msg" -ForegroundColor Green }
function Warn([string]$msg) { Write-Host "    !   $msg" -ForegroundColor Yellow }
function Info([string]$msg) { Write-Host "        $msg" }

Write-Host "`nSignature des scripts (éditeur IRIS)" -ForegroundColor Cyan
if (-not (Test-Path $cerPath)) {
  Warn "aucun certificat dans ce paquet (deploy\certs\iris-signature.cer) : scripts non signés — les lanceurs .cmd les exécutent quand même."
  exit 0
}
$cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList $cerPath
$thumb = $cert.Thumbprint
Info "certificat : $($cert.Subject)"
Info "empreinte  : $thumb (valable jusqu'au $($cert.NotAfter.ToString('dd/MM/yyyy')))"

function Open-Store([string]$name, [string]$location, [string]$mode) {
  $loc = [System.Security.Cryptography.X509Certificates.StoreLocation]$location
  $s = New-Object System.Security.Cryptography.X509Certificates.X509Store -ArgumentList $name, $loc
  $s.Open([System.Security.Cryptography.X509Certificates.OpenFlags]$mode)
  return $s
}
# Les certificats IRIS (même sujet) d'un magasin.
function Find-Iris([string]$name, [string]$location) {
  $s = Open-Store $name $location "ReadOnly"
  try { return @($s.Certificates | Where-Object { $_.Subject -eq $cert.Subject }) } finally { $s.Close() }
}
function Add-ToStore([string]$name, [string]$location) {
  $s = Open-Store $name $location "ReadWrite"
  try { $s.Add($cert) } finally { $s.Close() }
}
function Remove-FromStore([string]$name, [string]$location, $old) {
  $s = Open-Store $name $location "ReadWrite"
  try { $s.Remove($old) } finally { $s.Close() }
}

$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$where = if ($admin) { "LocalMachine" } else { "CurrentUser" }

# --- 1. état des magasins ----------------------------------------------------
$trusted = @{}
$others = @()
foreach ($store in "Root", "TrustedPublisher") {
  $found = @(Find-Iris $store "LocalMachine") + @(Find-Iris $store "CurrentUser")
  $trusted[$store] = @($found | Where-Object { $_.Thumbprint -eq $thumb }).Count -gt 0
  $others += @($found | Where-Object { $_.Thumbprint -ne $thumb })
}

# --- 2. approbation ----------------------------------------------------------
if ($trusted["Root"] -and $trusted["TrustedPublisher"]) {
  Ok "éditeur IRIS déjà approuvé sur cette station"
} elseif ($others.Count -gt 0 -and -not $Replace) {
  $old = ($others | Select-Object -ExpandProperty Thumbprint -Unique) -join ", "
  Warn "un AUTRE certificat IRIS est déjà approuvé ici (empreinte $old) : ce paquet est signé par une autre clé."
  Warn "rien n'est ajouté. Vérifier l'origine du paquet ; si le changement de clé est voulu : .\trust.cmd -Replace"
} else {
  try {
    if ($Replace) {
      # Changement de clé assumé : l'ancien éditeur IRIS n'est plus approuvé là où on le peut.
      foreach ($store in "Root", "TrustedPublisher") {
        foreach ($loc in @("CurrentUser") + @(if ($admin) { "LocalMachine" })) {
          foreach ($o in @(Find-Iris $store $loc | Where-Object { $_.Thumbprint -ne $thumb })) { Remove-FromStore $store $loc $o }
        }
      }
    }
    if (-not $trusted["TrustedPublisher"]) { Add-ToStore "TrustedPublisher" $where }
    $rootOk = $trusted["Root"]
    if (-not $rootOk) {
      if (-not $admin -and ($NoPrompt -or -not [Environment]::UserInteractive)) {
        Warn "racine de confiance non ajoutée (session sans dialogue) : lancer trust.cmd en administrateur."
      } else {
        if (-not $admin) { Info "Windows va demander de confirmer l'installation du certificat (empreinte $thumb) : répondre Oui." }
        Add-ToStore "Root" $where
        $rootOk = $true
      }
    }
    if ($rootOk) {
      Ok ("éditeur IRIS approuvé — " + $(if ($admin) { "pour toute la machine" } else { "pour l'utilisateur courant" }))
    }
  } catch {
    Warn "approbation non faite : $($_.Exception.Message)"
    Warn "les lanceurs .cmd exécutent quand même les scripts ; relancer trust.cmd (en administrateur : sans question)."
  }
}

# --- 3. vérification des signatures ------------------------------------------
$files = @(Get-ChildItem -Path $PSScriptRoot -Recurse -File -Include *.ps1, *.psm1, *.psd1)
$problems = @()
foreach ($f in $files) {
  $sig = Get-AuthenticodeSignature -FilePath $f.FullName
  $status = [string]$sig.Status
  if ($status -eq "Valid" -and $sig.SignerCertificate.Thumbprint -eq $thumb) { continue }
  $why = switch ($status) {
    "NotSigned" { "non signé" }
    "HashMismatch" { "MODIFIÉ depuis sa signature — ne pas l'exécuter sans savoir pourquoi" }
    "Valid" { "signé par un autre éditeur : $($sig.SignerCertificate.Subject)" }
    default { "signature intacte, éditeur pas encore approuvé ici ($status)" }
  }
  $problems += "$($f.Name) : $why"
}
if ($problems.Count -eq 0) {
  Ok "$($files.Count) script(s) : signature valide, éditeur IRIS"
} else {
  foreach ($p in $problems) { Warn $p }
}
exit 0

# SIG # Begin signature block
# MIIIAAYJKoZIhvcNAQcCoIIH8TCCB+0CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBVeqKwtHgbrPCl
# PlBqP/baU+JU6TFbGr2bUq9JV1iV4aCCBIgwggSEMIIC7KADAgECAhQZkZL6AS29
# ZKT8EZ/67bkku/cubjANBgkqhkiG9w0BAQsFADBRMS0wKwYDVQQDDCRJUklTIFN0
# YXRpb24gLSBTaWduYXR1cmUgZGVzIHNjcmlwdHMxEzARBgNVBAoMCkFSR09TIFJE
# SUExCzAJBgNVBAYTAk1BMB4XDTI2MDkyMzEyMzgxN1oXDTM2MDkyMDEyMzgxN1ow
# UTEtMCsGA1UEAwwkSVJJUyBTdGF0aW9uIC0gU2lnbmF0dXJlIGRlcyBzY3JpcHRz
# MRMwEQYDVQQKDApBUkdPUyBSRElBMQswCQYDVQQGEwJNQTCCAaIwDQYJKoZIhvcN
# AQEBBQADggGPADCCAYoCggGBAK/tnaiuF/+Zp8YrShYI3zjt29xXDNA6kZzDjzP8
# +J3/TePVTg0r8zdRDjpJJP3M2Y8OK6qrv+P6bAQhlKu+8/GyQozhzc1MBL2ofg5F
# wj6R3G1lR/5knQsx3yg8fQO+ALhs4P6miSEoLYv117dntRoM/0dX1iwl18p4yLQn
# DFREkyuWpa8w9rAPkukcjWbUagC47He9O0Ge8bztZA1kQ610uNzKSfCQuiKrigfK
# Uzv+1CEBYW4FTG1X025zUJlxIcrHvw3csO06xYdhdpU5EzD2bd4m10ERP3fyN1cI
# 2uZwzzHcXolEaTlVrhR7OUv84UgXg69F5pvjg5iVNZXIa+KUipbIjP7/fGQh2EEy
# q1yN9eoabO8/A8cEFEKRpYurIVj3IUaDNAGqZidA2mLwkvMlW8QoMqtFYfIhqqD8
# c36ORhoAYGVFHT7r1Uze04qIWqzJtwqrKzwrx4pYJ1tQ3gZl+D+4jpnToEpdgVYd
# /+cYjOX6XWAcKyM2iOONuSRoaQIDAQABo1QwUjAMBgNVHRMBAf8EAjAAMA4GA1Ud
# DwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQU7GYdjyRk
# iy+ab2VKRGKrVEsHxaEwDQYJKoZIhvcNAQELBQADggGBADb3foUiOzMXmWawsIKF
# vnn0+Lp+XappmlS0VnQDPiuWx2ccclWAXuiCQlCIhh0tZXbBc5bhJ0P3BpeKZcPX
# ZBXSK8sGTHzDEIufRgqERY41vfpeonZ31N2yuiDUoN0beqjTs5BeQskmAM/wmeg8
# hoxSLRVMY04lM/MHmlr6zbgAQg+fU1lQAj7EWCQWwjrrVgJU6P5Jfw4SZTTAp5Cw
# j7Q+s87DzgJIvf2kr0D+RMynE7M7qJx53rXsLM2LR4A5EwIow4QfjWa2JH1SIsdy
# tWIyjouU9djojBhjCSDnYYiMWDU2+0mgTAeSx0qtNNp8W5Mw7RWaHx/q/h++WzzV
# UnIAb4bDRTugECpUu1APAC1EymM4/EcChi8icMyKg9uucgFEG8c+ECBQZDS0RewZ
# Z4QfZ9WNH/w942ho7bIOvlHEsL/h9cI6vcInVH1Z7qkTMYu/Gxa49G4WmQW3i62b
# GJRgoE9MmGMY0X9Tu6h12Q9sEZN13Lz6Tu/3JqFE4TrCgDGCAs4wggLKAgEBMGkw
# UTEtMCsGA1UEAwwkSVJJUyBTdGF0aW9uIC0gU2lnbmF0dXJlIGRlcyBzY3JpcHRz
# MRMwEQYDVQQKDApBUkdPUyBSRElBMQswCQYDVQQGEwJNQQIUGZGS+gEtvWSk/BGf
# +u25JLv3Lm4wDQYJYIZIAWUDBAIBBQCggbcwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYJKoZIhvcNAQkFMQ8XDTI2MDkyNDAwMzk1MlowHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwLQYKKwYBBAGCNwIBDDEfMB2gG4EZSVJJUyAtIHNj
# cmlwdHMgZGUgc3RhdGlvbjAvBgkqhkiG9w0BCQQxIgQgK2cWZ9tVT+2fq/lYdqJe
# QJXR4syUYMz+Vcle/Ub0rTEwDQYJKoZIhvcNAQEBBQAEggGApFpBD845nQaq/8Jw
# RPh/BuS+UWVr1LkEhOnkYnwIOV3K6g4YnI1eznmeSQvNf/1i7qTJ7oqM37U+3vWc
# nsIGOGmtWc0vTrJ9CKF5vgnEAobtNKLoI2NX6PPS0AEGvyigMf0LJh8ANvAAXL2f
# XFbPu+ua6VK0AsJvTR3LSe5vP3qrbdWylo1DdNU2NHm16xrRJ1Zi1T4b5ydWbQjw
# g9VXqsyop1A84EvlDeaKnsuDSItKHe/THUMHkssG2XjAEFNOfMDr2IPr/MXL1qyV
# Uon5PPFxSPfbi4IRya8tNJIOEhQzd0Z0hmrWp7b6qNql9a44Bs+fH1h5O1VDM8wG
# b11eujfF9hVMjtHHEBTI3JHJywUQgdCMvo1GR01tHAbA3RoGsy9MoanqfFT4yDTh
# m+d6qDm5TXRN0XkYYFXTdYQczmPnnzfrKyxv57MU8uZHPYAA7Mhg+mtzfDogE0cK
# kgb0KaJxe1IJNVh0/lgirjQMgXrVxK7IRFbXHrhltvUD6k7H
# SIG # End signature block
