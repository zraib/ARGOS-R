﻿# ============================================================================
# ARGOS / IRIS — sauvegarde de la station (PowerShell, Docker Desktop)
#
# Deux choses à garder, parce que deux persistances :
#   1. la base PostgreSQL (audit, drapeaux, bons de travail)   → pg_dump
#   2. le volume /data de l'API (instantané JSON du domaine et des comptes,
#      pièces jointes)                                         → archive tar
# Usage :  .\scripts\backup.ps1 [-Dest D:\sauvegardes\iris]
# ============================================================================
param([string]$Dest = (Join-Path $PSScriptRoot "..\backups"))

$ErrorActionPreference = "Stop"
# Sans `-f` : docker compose lit COMPOSE_FILE dans .env (HTTPS activé ou non — README § 11).
$deploy = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
New-Item -ItemType Directory -Force -Path $Dest | Out-Null

$env = Get-Content (Join-Path $PSScriptRoot "..\.env") | Where-Object { $_ -match "^\s*[A-Z_]+=" }
$dbUser = (($env | Where-Object { $_ -like "POSTGRES_USER=*" }) -split "=", 2)[1]; if (-not $dbUser) { $dbUser = "argos" }
$dbName = (($env | Where-Object { $_ -like "POSTGRES_DB=*" }) -split "=", 2)[1];   if (-not $dbName) { $dbName = "argos" }

Write-Host "1/2  PostgreSQL → $Dest\db-$stamp.sql.gz"
docker compose --project-directory $deploy exec -T db pg_dump -U $dbUser -d $dbName --no-owner | & docker run --rm -i alpine:3.20 gzip -9 > "$Dest\db-$stamp.sql.gz"
if ($LASTEXITCODE -ne 0) { throw "pg_dump a échoué" }

Write-Host "2/2  Volume de l'API (instantané JSON + pièces jointes) → $Dest\api-data-$stamp.tar.gz"
docker run --rm -v iris_api_data:/data:ro -v "${Dest}:/out" alpine:3.20 tar czf "/out/api-data-$stamp.tar.gz" -C /data .
if ($LASTEXITCODE -ne 0) { throw "archivage du volume api_data échoué" }

Get-ChildItem $Dest -Filter "*$stamp*" | Format-Table Name, @{n="Mo";e={[math]::Round($_.Length/1MB,1)}}
Write-Host "Sauvegarde terminée. Restauration : .\scripts\restore.ps1 -Stamp $stamp"

# SIG # Begin signature block
# MIIIAAYJKoZIhvcNAQcCoIIH8TCCB+0CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDV4EWnxIE85JWP
# IcKz3QOO1tSS0eulhspXPvr6QF8h/aCCBIgwggSEMIIC7KADAgECAhQZkZL6AS29
# ZKT8EZ/67bkku/cubjANBgkqhkiG9w0BAQsFADBRMS0wKwYDVQQDDCRJUklTIFN0
# YXRpb24gLSBTaWduYXR1cmUgZGVzIHNjcmlwdHMxEzARBgNVBAoMCkFSR09TIFJE
# SUExCzAJBgNVBAYTAk1BMB4XDTI2MDkyMzEyMzgxN1oXDTM2MDkyMDEyMzgxN1ow
# UTEtMCsGA1UEAwwkSVJJUyBTdGF0aW9uIC0gU2lnbmF0dXJlIGRlcyBzY3JpcHRz
# MRMwEQYDVQQKDApBUkdPUyBSRElBMQswCQYDVQQGEwJNQTCCAaIwDQYJKoZIhvcN
# AQEBBQADggGPADCCAYoCggGBAK/tnaiuF/+Zp8YrShYI3zjt29xXDNA6kZzDjzP8
# +J3/TePVTg0r8zdRDjpJJP3M2Y8OK6qrv+P6bAQhlKu+8/GyQozhzc1MBL2ofg5F
# wj6R3G1lR/5knQsx3yg8fQO+ALhs4P6miSEoLYv117dntRoM/0dX1iwl18p4yLQn
# DFREkyuWpa8w9rAPkukcjWbUagC47He9O0Ge8bztZA1kQ610uNzKSfCQuiKrigfK
# Uzv+1CEBYW4FTG1X025zUJlxIcrHvw3csO06xYdhdpU5EzD2bd4m10ERP3fyN1cI
# 2uZwzzHcXolEaTlVrhR7OUv84UgXg69F5pvjg5iVNZXIa+KUipbIjP7/fGQh2EEy
# q1yN9eoabO8/A8cEFEKRpYurIVj3IUaDNAGqZidA2mLwkvMlW8QoMqtFYfIhqqD8
# c36ORhoAYGVFHT7r1Uze04qIWqzJtwqrKzwrx4pYJ1tQ3gZl+D+4jpnToEpdgVYd
# /+cYjOX6XWAcKyM2iOONuSRoaQIDAQABo1QwUjAMBgNVHRMBAf8EAjAAMA4GA1Ud
# DwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQU7GYdjyRk
# iy+ab2VKRGKrVEsHxaEwDQYJKoZIhvcNAQELBQADggGBADb3foUiOzMXmWawsIKF
# vnn0+Lp+XappmlS0VnQDPiuWx2ccclWAXuiCQlCIhh0tZXbBc5bhJ0P3BpeKZcPX
# ZBXSK8sGTHzDEIufRgqERY41vfpeonZ31N2yuiDUoN0beqjTs5BeQskmAM/wmeg8
# hoxSLRVMY04lM/MHmlr6zbgAQg+fU1lQAj7EWCQWwjrrVgJU6P5Jfw4SZTTAp5Cw
# j7Q+s87DzgJIvf2kr0D+RMynE7M7qJx53rXsLM2LR4A5EwIow4QfjWa2JH1SIsdy
# tWIyjouU9djojBhjCSDnYYiMWDU2+0mgTAeSx0qtNNp8W5Mw7RWaHx/q/h++WzzV
# UnIAb4bDRTugECpUu1APAC1EymM4/EcChi8icMyKg9uucgFEG8c+ECBQZDS0RewZ
# Z4QfZ9WNH/w942ho7bIOvlHEsL/h9cI6vcInVH1Z7qkTMYu/Gxa49G4WmQW3i62b
# GJRgoE9MmGMY0X9Tu6h12Q9sEZN13Lz6Tu/3JqFE4TrCgDGCAs4wggLKAgEBMGkw
# UTEtMCsGA1UEAwwkSVJJUyBTdGF0aW9uIC0gU2lnbmF0dXJlIGRlcyBzY3JpcHRz
# MRMwEQYDVQQKDApBUkdPUyBSRElBMQswCQYDVQQGEwJNQQIUGZGS+gEtvWSk/BGf
# +u25JLv3Lm4wDQYJYIZIAWUDBAIBBQCggbcwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYJKoZIhvcNAQkFMQ8XDTI2MDkyNDAwMzk1MlowHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwLQYKKwYBBAGCNwIBDDEfMB2gG4EZSVJJUyAtIHNj
# cmlwdHMgZGUgc3RhdGlvbjAvBgkqhkiG9w0BCQQxIgQgGzVuEHE4tExgyHxZFTwj
# yD2loBA7PhgTNvCtMNYugzUwDQYJKoZIhvcNAQEBBQAEggGAofwIJuQnt7gF4LyR
# VebBTWeQ1CWtpqJ8qtyagrJujHK8LBpaOpHkAtG2eFiNKksKyKUtwOccvOkI82Ls
# ekMkm1NKa0o/MyzR5Y+ZfS7BUfwUYXTLJebLgvrm8xrVvjyZ6KEAkFPPCw9hiVdn
# fZmjXvSUQSc6HYUBSoZFli8IVt0QexwcgZJYyAOfoE2u68dP/pyES2JO2NXyk12J
# O6y5i2aiDgpNiqcsKLVAw7sHv9JvlIMtuBjLP4hrs5znYEIBcZvBXw5GRiguYWRx
# adqFBrksj9g2UixA348V+hEiO5GhYSByaA9pdD8IBrbMHW3VYn6n25YUDL1UGgsU
# E0W/U9NNJKSY9qrVB6Rsv6ZEyUhVsyniFz0IQH4Sjve9OEtAn2dEV2lOWTwIBCP4
# FOHM2ETFCsIiP8MJkzaKxUwOtz3z6PDDWZkE0u1tHHG16vvGzjBH8eMzbK8MRjI2
# aULZDcdy/wIzJXZOHdZna50FUVNPTrDjDoC0Lo6hULRln8t/
# SIG # End signature block
