﻿# ============================================================================
# ARGOS / IRIS — import des tuiles hors ligne dans le volume de la station
# (version RIF, sans Internet). PowerShell, Docker Desktop.
#
# L'archive (iris-tiles-<version>.tar, fabriquée par scripts/tiles-export.sh
# sur une machine qui a Internet) contient tout ce que la carte affiche :
# imagerie, relief 3D, plan et toponymes vectoriels du Maroc, polices.
#
# Usage :  .\scripts\tiles-import.ps1 [-Archive D:\iris-tiles-20260919-abc1234.tar]
#   Sans -Archive : la première archive .tar trouvée dans deploy\tiles-data\.
# Relançable : les fichiers du volume sont remplacés ; le serveur de tuiles
# est redémarré s'il tourne. install.ps1 appelle ce script de lui-même quand
# deploy\tiles-data\ contient une archive.
# ============================================================================
param([string]$Archive = "")
$ErrorActionPreference = "Stop"
$deploy = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$volume = "iris_argos_tiles"
if (-not $Archive) {
  $dir = Join-Path $deploy "tiles-data"
  if (Test-Path $dir) { $Archive = (Get-ChildItem -Path $dir -File -Filter "*.tar" | Sort-Object Name | Select-Object -First 1).FullName }
}
if (-not $Archive -or -not (Test-Path $Archive)) { throw "Aucune archive de tuiles : passer -Archive <fichier .tar> ou déposer l'archive dans deploy\tiles-data\." }
$Archive = (Resolve-Path $Archive).Path
$shaFile = "$Archive.sha256"
if (Test-Path $shaFile) {
  $expected = ((Get-Content $shaFile | Select-Object -First 1) -split "\s+")[0].ToLower()
  $got = (Get-FileHash -Algorithm SHA256 $Archive).Hash.ToLower()
  if ($expected -ne $got) { throw "Empreinte SHA-256 incorrecte pour $Archive : archive altérée ou copie incomplète." }
  Write-Host "    OK  empreinte vérifiée" -ForegroundColor Green
}
& docker volume create $volume | Out-Null
$srcDir = Split-Path $Archive -Parent
$file = Split-Path $Archive -Leaf
Write-Host "[tuiles] import de $file dans le volume $volume (plusieurs Go : quelques minutes)…" -ForegroundColor Cyan
& docker run --rm -v "${volume}:/data" -v "${srcDir}:/src:ro" alpine:3.20 sh -c "tar -xf /src/$file -C /data && ls -la /data/*.mbtiles"
if ($LASTEXITCODE -ne 0) { throw "L'import a échoué (docker run)." }
$running = & docker compose --project-directory $deploy ps --status running --services 2>$null
if ($running -contains "tiles") {
  & docker compose --project-directory $deploy restart tiles | Out-Null
  Write-Host "    OK  serveur de tuiles redémarré" -ForegroundColor Green
}
Write-Host "    OK  tuiles importées — carte hors ligne prête (MAP_TILES=sovereign, COMPOSE_PROFILES=sovereign dans .env)" -ForegroundColor Green

# SIG # Begin signature block
# MIIIAAYJKoZIhvcNAQcCoIIH8TCCB+0CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAXGIsxRMhMj4Oa
# KofgkDDyCidTCkAbP4VemaJzwnACYqCCBIgwggSEMIIC7KADAgECAhQZkZL6AS29
# ZKT8EZ/67bkku/cubjANBgkqhkiG9w0BAQsFADBRMS0wKwYDVQQDDCRJUklTIFN0
# YXRpb24gLSBTaWduYXR1cmUgZGVzIHNjcmlwdHMxEzARBgNVBAoMCkFSR09TIFJE
# SUExCzAJBgNVBAYTAk1BMB4XDTI2MDkyMzEyMzgxN1oXDTM2MDkyMDEyMzgxN1ow
# UTEtMCsGA1UEAwwkSVJJUyBTdGF0aW9uIC0gU2lnbmF0dXJlIGRlcyBzY3JpcHRz
# MRMwEQYDVQQKDApBUkdPUyBSRElBMQswCQYDVQQGEwJNQTCCAaIwDQYJKoZIhvcN
# AQEBBQADggGPADCCAYoCggGBAK/tnaiuF/+Zp8YrShYI3zjt29xXDNA6kZzDjzP8
# +J3/TePVTg0r8zdRDjpJJP3M2Y8OK6qrv+P6bAQhlKu+8/GyQozhzc1MBL2ofg5F
# wj6R3G1lR/5knQsx3yg8fQO+ALhs4P6miSEoLYv117dntRoM/0dX1iwl18p4yLQn
# DFREkyuWpa8w9rAPkukcjWbUagC47He9O0Ge8bztZA1kQ610uNzKSfCQuiKrigfK
# Uzv+1CEBYW4FTG1X025zUJlxIcrHvw3csO06xYdhdpU5EzD2bd4m10ERP3fyN1cI
# 2uZwzzHcXolEaTlVrhR7OUv84UgXg69F5pvjg5iVNZXIa+KUipbIjP7/fGQh2EEy
# q1yN9eoabO8/A8cEFEKRpYurIVj3IUaDNAGqZidA2mLwkvMlW8QoMqtFYfIhqqD8
# c36ORhoAYGVFHT7r1Uze04qIWqzJtwqrKzwrx4pYJ1tQ3gZl+D+4jpnToEpdgVYd
# /+cYjOX6XWAcKyM2iOONuSRoaQIDAQABo1QwUjAMBgNVHRMBAf8EAjAAMA4GA1Ud
# DwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQU7GYdjyRk
# iy+ab2VKRGKrVEsHxaEwDQYJKoZIhvcNAQELBQADggGBADb3foUiOzMXmWawsIKF
# vnn0+Lp+XappmlS0VnQDPiuWx2ccclWAXuiCQlCIhh0tZXbBc5bhJ0P3BpeKZcPX
# ZBXSK8sGTHzDEIufRgqERY41vfpeonZ31N2yuiDUoN0beqjTs5BeQskmAM/wmeg8
# hoxSLRVMY04lM/MHmlr6zbgAQg+fU1lQAj7EWCQWwjrrVgJU6P5Jfw4SZTTAp5Cw
# j7Q+s87DzgJIvf2kr0D+RMynE7M7qJx53rXsLM2LR4A5EwIow4QfjWa2JH1SIsdy
# tWIyjouU9djojBhjCSDnYYiMWDU2+0mgTAeSx0qtNNp8W5Mw7RWaHx/q/h++WzzV
# UnIAb4bDRTugECpUu1APAC1EymM4/EcChi8icMyKg9uucgFEG8c+ECBQZDS0RewZ
# Z4QfZ9WNH/w942ho7bIOvlHEsL/h9cI6vcInVH1Z7qkTMYu/Gxa49G4WmQW3i62b
# GJRgoE9MmGMY0X9Tu6h12Q9sEZN13Lz6Tu/3JqFE4TrCgDGCAs4wggLKAgEBMGkw
# UTEtMCsGA1UEAwwkSVJJUyBTdGF0aW9uIC0gU2lnbmF0dXJlIGRlcyBzY3JpcHRz
# MRMwEQYDVQQKDApBUkdPUyBSRElBMQswCQYDVQQGEwJNQQIUGZGS+gEtvWSk/BGf
# +u25JLv3Lm4wDQYJYIZIAWUDBAIBBQCggbcwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYJKoZIhvcNAQkFMQ8XDTI2MDkyNDAwMzk1MlowHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwLQYKKwYBBAGCNwIBDDEfMB2gG4EZSVJJUyAtIHNj
# cmlwdHMgZGUgc3RhdGlvbjAvBgkqhkiG9w0BCQQxIgQgztWKnjusAKAWPiAf4+My
# 4eV+SoVDzR4xp1HbWoSKf+UwDQYJKoZIhvcNAQEBBQAEggGArLBpRRutw8l+9Ly5
# 51+zdo+FoMdAdpE1Wx1fJZ0VeEroZJ//Nek9vS/drEGs7R7ePK1TBBKMKmfKogx0
# dsS5zSlrqIktpgUkNr59I1FIHk3CP00IMPT2Y0OIwICSH10t18Zl2iQgUrx37DIY
# xNimTfiWZgHpRJxhg4co6KHjVbctBQ91ElnNjurSXOgfzuVMT0inyutbIxcjhRVi
# Ow9kwM0qhGN+9Z0EALaRvZi/EqK1XekAABtWbJOFKCGn6HYtauhvWedZPyBd6BEf
# V3mQtjjp0EK2KiUNcHhzLqaId/sMOlu48+KVarfPIlrLcUqmETCm65AQlffUW5y+
# xdl6/HJsUWPycKdKlf1s6KcwABsdpJFzJXK82r4/Brfw2H8Vv+HMpK9vTce5xOvk
# mWLlebzYBylfGR0shCmYlu/IymxUm2BiIMZTir6mfl1Ek0Iz3At4jiC1cBA3xDoM
# 6ed0WMGoqno05DxbHx62BjcPF2RFj01XiOaLOwmySif1eerv
# SIG # End signature block
