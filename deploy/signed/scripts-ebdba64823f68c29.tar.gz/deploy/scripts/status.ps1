﻿# ARGOS / IRIS — état de la station : services, santé, tuiles, volumes
# Sans `-f` : docker compose lit COMPOSE_FILE dans .env (HTTPS activé ou non — README § 11).
$deploy = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
docker compose --project-directory $deploy ps
# Adresse locale de la station : https si .env active un des empilements HTTPS
# (compose.https.yml / compose.letsencrypt.yml — README § 11), sinon http. Le
# certificat auto-signé est accepté pour les sondes de ce script seulement.
function Get-EnvValue([string]$file, [string]$key, [string]$default) {
  if (-not (Test-Path $file)) { return $default }
  $line = Get-Content $file | Where-Object { $_ -match "^\s*$key=(.*)$" } | Select-Object -Last 1
  if ($line -and $line -match "^\s*$key=(.*)$") { return $Matches[1].Trim() }
  return $default
}
function Get-StationUrl([string]$file) {
  [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
  if ((Get-EnvValue $file "COMPOSE_FILE" "") -match "https|letsencrypt") {
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
    $p = [int](Get-EnvValue $file "HTTPS_PORT" "443")
    if ($p -eq 443) { return "https://localhost" } else { return "https://localhost:$p" }
  }
  $p = [int](Get-EnvValue $file "HTTP_PORT" "80")
  if ($p -eq 80) { return "http://localhost" } else { return "http://localhost:$p" }
}
$envFile = Join-Path $deploy ".env"
$url = Get-StationUrl $envFile
# Accès public par tunnel sortant (ADR 0028), s'il est ouvert : l'adresse se lit dans le journal du tunnel rapide.
$quick = docker compose --project-directory $deploy ps -q tunnel-quick 2>$null
$named = docker compose --project-directory $deploy ps -q tunnel 2>$null
if ($quick) {
  $log = docker compose --project-directory $deploy logs --no-color --no-log-prefix tunnel-quick 2>$null
  $m = [regex]::Matches(($log -join "`n"), "https://[a-z0-9-]+\.trycloudflare\.com") | Select-Object -Last 1
  Write-Host "`nAccès public (tunnel rapide) : $(if ($m) { $m.Value } else { 'en cours de démarrage' })   — fermer : .\scripts\expose.ps1 -Off"
} elseif ($named) {
  Write-Host "`nAccès public (tunnel nommé) actif — adresse : votre tableau de bord Cloudflare Zero Trust   — fermer : .\scripts\expose.ps1 -Off"
}
Write-Host "`nSanté de l'API ($url) :"
try { (Invoke-WebRequest -UseBasicParsing "$url/api/health").Content } catch { Write-Host "  injoignable : $_" }
# Tuiles : seulement en fond de carte souverain (MAP_TILES dans .env) ; en
# externe, le navigateur appelle les fournisseurs et la station n'en sert pas.
$mapMode = "external"
if (Test-Path $envFile) {
  $mapLine = Get-Content $envFile | Where-Object { $_ -match "^\s*MAP_TILES=(\w+)" } | Select-Object -Last 1
  if ($mapLine -and $mapLine -match "^\s*MAP_TILES=(\w+)") { $mapMode = $Matches[1] }
}
if ($mapMode -eq "sovereign") {
  Write-Host "`nCatalogue des tuiles :"
  try { (Invoke-WebRequest -UseBasicParsing "$url/tiles/").StatusCode } catch { Write-Host "  injoignable : $_" }
  Write-Host "`nTuiles provisionnées :"
  docker compose --project-directory $deploy run --rm tiles-fetch status
} else {
  Write-Host "`nFond de carte : externe (Esri/Maxar, OpenStreetMap, relief en ligne) — pas de serveur de tuiles sur la station."
}
Write-Host "`nVolumes :"
docker system df -v | Select-String "iris_"

# SIG # Begin signature block
# MIIIAAYJKoZIhvcNAQcCoIIH8TCCB+0CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB4fPy+r4t9Ap4X
# Ohj7AnOo2J7NjQ6h2d0/LsJsCv7mW6CCBIgwggSEMIIC7KADAgECAhQZkZL6AS29
# ZKT8EZ/67bkku/cubjANBgkqhkiG9w0BAQsFADBRMS0wKwYDVQQDDCRJUklTIFN0
# YXRpb24gLSBTaWduYXR1cmUgZGVzIHNjcmlwdHMxEzARBgNVBAoMCkFSR09TIFJE
# SUExCzAJBgNVBAYTAk1BMB4XDTI2MDkyMzEyMzgxN1oXDTM2MDkyMDEyMzgxN1ow
# UTEtMCsGA1UEAwwkSVJJUyBTdGF0aW9uIC0gU2lnbmF0dXJlIGRlcyBzY3JpcHRz
# MRMwEQYDVQQKDApBUkdPUyBSRElBMQswCQYDVQQGEwJNQTCCAaIwDQYJKoZIhvcN
# AQEBBQADggGPADCCAYoCggGBAK/tnaiuF/+Zp8YrShYI3zjt29xXDNA6kZzDjzP8
# +J3/TePVTg0r8zdRDjpJJP3M2Y8OK6qrv+P6bAQhlKu+8/GyQozhzc1MBL2ofg5F
# wj6R3G1lR/5knQsx3yg8fQO+ALhs4P6miSEoLYv117dntRoM/0dX1iwl18p4yLQn
# DFREkyuWpa8w9rAPkukcjWbUagC47He9O0Ge8bztZA1kQ610uNzKSfCQuiKrigfK
# Uzv+1CEBYW4FTG1X025zUJlxIcrHvw3csO06xYdhdpU5EzD2bd4m10ERP3fyN1cI
# 2uZwzzHcXolEaTlVrhR7OUv84UgXg69F5pvjg5iVNZXIa+KUipbIjP7/fGQh2EEy
# q1yN9eoabO8/A8cEFEKRpYurIVj3IUaDNAGqZidA2mLwkvMlW8QoMqtFYfIhqqD8
# c36ORhoAYGVFHT7r1Uze04qIWqzJtwqrKzwrx4pYJ1tQ3gZl+D+4jpnToEpdgVYd
# /+cYjOX6XWAcKyM2iOONuSRoaQIDAQABo1QwUjAMBgNVHRMBAf8EAjAAMA4GA1Ud
# DwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQU7GYdjyRk
# iy+ab2VKRGKrVEsHxaEwDQYJKoZIhvcNAQELBQADggGBADb3foUiOzMXmWawsIKF
# vnn0+Lp+XappmlS0VnQDPiuWx2ccclWAXuiCQlCIhh0tZXbBc5bhJ0P3BpeKZcPX
# ZBXSK8sGTHzDEIufRgqERY41vfpeonZ31N2yuiDUoN0beqjTs5BeQskmAM/wmeg8
# hoxSLRVMY04lM/MHmlr6zbgAQg+fU1lQAj7EWCQWwjrrVgJU6P5Jfw4SZTTAp5Cw
# j7Q+s87DzgJIvf2kr0D+RMynE7M7qJx53rXsLM2LR4A5EwIow4QfjWa2JH1SIsdy
# tWIyjouU9djojBhjCSDnYYiMWDU2+0mgTAeSx0qtNNp8W5Mw7RWaHx/q/h++WzzV
# UnIAb4bDRTugECpUu1APAC1EymM4/EcChi8icMyKg9uucgFEG8c+ECBQZDS0RewZ
# Z4QfZ9WNH/w942ho7bIOvlHEsL/h9cI6vcInVH1Z7qkTMYu/Gxa49G4WmQW3i62b
# GJRgoE9MmGMY0X9Tu6h12Q9sEZN13Lz6Tu/3JqFE4TrCgDGCAs4wggLKAgEBMGkw
# UTEtMCsGA1UEAwwkSVJJUyBTdGF0aW9uIC0gU2lnbmF0dXJlIGRlcyBzY3JpcHRz
# MRMwEQYDVQQKDApBUkdPUyBSRElBMQswCQYDVQQGEwJNQQIUGZGS+gEtvWSk/BGf
# +u25JLv3Lm4wDQYJYIZIAWUDBAIBBQCggbcwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYJKoZIhvcNAQkFMQ8XDTI2MDkyNDAwMzk1MlowHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwLQYKKwYBBAGCNwIBDDEfMB2gG4EZSVJJUyAtIHNj
# cmlwdHMgZGUgc3RhdGlvbjAvBgkqhkiG9w0BCQQxIgQgzHIheBG9nPIu/My6F8ju
# NtJ6KK13+WPzkpFA0BNgZ2swDQYJKoZIhvcNAQEBBQAEggGAP7TTmsJuGkwDFydn
# Zy1Gwxoup4tO53obHlbeXXaqcD5B+UWuaBVIggV6AdCecqTTV1ix/dcPczBc9W6G
# EcFOvZnVjOVRFqj2GXLDinFrysKbFPyfPhoFCekz/MK0zxvXnJOJqF7sNsqQHrtG
# pxnHwvrbAxo1ekNiAX49Fu8N+Dfu71tw82b4syd9kSnjEsrMNyNpRWzLrdUkA2en
# HLwP5oaY2s94WL2RM7hTwug26rICJ62xvjF6VI4skuvgoFY9IKsLxkei6IFP8qXG
# x0V+R7+YL9JfipQSnrncqTrJmsftFDy6+HCBMloT+oEekW4aqKBphTUCufwTyzFs
# uNWyeqBEg9XO+4SG5ZHPT0LvawKI1y3unS4CD06gsU16HayuK0L0GmgW6pALl0hI
# xtetE4Xrrm89Lx3OPwgBDK6ooaxTFqVGBkmV85nf8ievPxO3AoF4yK9I80Rz5EsD
# 1GllL0jUMaUe+tBnz62BYotlYss4w1ONHVilpM07tIEfHQ4t
# SIG # End signature block
