﻿# ============================================================================
# ARGOS / IRIS — restauration d'une sauvegarde (PowerShell, Docker Desktop)
# Usage :  .\scripts\restore.ps1 -Stamp 20260914-103000 [-Source D:\sauvegardes\iris]
# ARRÊTE l'API le temps de remettre le volume, puis redémarre la pile.
# ============================================================================
param(
  [Parameter(Mandatory = $true)][string]$Stamp,
  [string]$Source = (Join-Path $PSScriptRoot "..\backups")
)

$ErrorActionPreference = "Stop"
# Sans `-f` : docker compose lit COMPOSE_FILE dans .env (HTTPS activé ou non — README § 11).
$deploy = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$dump = Join-Path $Source "db-$Stamp.sql.gz"
$tar  = Join-Path $Source "api-data-$Stamp.tar.gz"
if (-not (Test-Path $dump) -or -not (Test-Path $tar)) { throw "Sauvegarde $Stamp introuvable dans $Source" }

$env = Get-Content (Join-Path $PSScriptRoot "..\.env") | Where-Object { $_ -match "^\s*[A-Z_]+=" }
$dbUser = (($env | Where-Object { $_ -like "POSTGRES_USER=*" }) -split "=", 2)[1]; if (-not $dbUser) { $dbUser = "argos" }
$dbName = (($env | Where-Object { $_ -like "POSTGRES_DB=*" }) -split "=", 2)[1];   if (-not $dbName) { $dbName = "argos" }

Write-Host "Arrêt de l'API et du proxy"
docker compose --project-directory $deploy stop proxy api

Write-Host "1/2  Base PostgreSQL ← $dump"
Get-Content $dump -AsByteStream -Raw | docker run --rm -i alpine:3.20 gunzip -c | docker compose --project-directory $deploy exec -T db psql -U $dbUser -d $dbName -q
if ($LASTEXITCODE -ne 0) { throw "restauration PostgreSQL échouée" }

Write-Host "2/2  Volume de l'API ← $tar"
docker run --rm -v iris_api_data:/data -v "${Source}:/in:ro" alpine:3.20 sh -c "rm -rf /data/* && tar xzf /in/api-data-$Stamp.tar.gz -C /data"
if ($LASTEXITCODE -ne 0) { throw "restauration du volume api_data échouée" }

Write-Host "Redémarrage"
docker compose --project-directory $deploy up -d
Write-Host "Restauration $Stamp terminée."

# SIG # Begin signature block
# MIIIAAYJKoZIhvcNAQcCoIIH8TCCB+0CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB7M0a/yIiFtx+b
# O3i0f8keSAfp+zQX7c+QEtxyyrsQNKCCBIgwggSEMIIC7KADAgECAhQZkZL6AS29
# ZKT8EZ/67bkku/cubjANBgkqhkiG9w0BAQsFADBRMS0wKwYDVQQDDCRJUklTIFN0
# YXRpb24gLSBTaWduYXR1cmUgZGVzIHNjcmlwdHMxEzARBgNVBAoMCkFSR09TIFJE
# SUExCzAJBgNVBAYTAk1BMB4XDTI2MDkyMzEyMzgxN1oXDTM2MDkyMDEyMzgxN1ow
# UTEtMCsGA1UEAwwkSVJJUyBTdGF0aW9uIC0gU2lnbmF0dXJlIGRlcyBzY3JpcHRz
# MRMwEQYDVQQKDApBUkdPUyBSRElBMQswCQYDVQQGEwJNQTCCAaIwDQYJKoZIhvcN
# AQEBBQADggGPADCCAYoCggGBAK/tnaiuF/+Zp8YrShYI3zjt29xXDNA6kZzDjzP8
# +J3/TePVTg0r8zdRDjpJJP3M2Y8OK6qrv+P6bAQhlKu+8/GyQozhzc1MBL2ofg5F
# wj6R3G1lR/5knQsx3yg8fQO+ALhs4P6miSEoLYv117dntRoM/0dX1iwl18p4yLQn
# DFREkyuWpa8w9rAPkukcjWbUagC47He9O0Ge8bztZA1kQ610uNzKSfCQuiKrigfK
# Uzv+1CEBYW4FTG1X025zUJlxIcrHvw3csO06xYdhdpU5EzD2bd4m10ERP3fyN1cI
# 2uZwzzHcXolEaTlVrhR7OUv84UgXg69F5pvjg5iVNZXIa+KUipbIjP7/fGQh2EEy
# q1yN9eoabO8/A8cEFEKRpYurIVj3IUaDNAGqZidA2mLwkvMlW8QoMqtFYfIhqqD8
# c36ORhoAYGVFHT7r1Uze04qIWqzJtwqrKzwrx4pYJ1tQ3gZl+D+4jpnToEpdgVYd
# /+cYjOX6XWAcKyM2iOONuSRoaQIDAQABo1QwUjAMBgNVHRMBAf8EAjAAMA4GA1Ud
# DwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQU7GYdjyRk
# iy+ab2VKRGKrVEsHxaEwDQYJKoZIhvcNAQELBQADggGBADb3foUiOzMXmWawsIKF
# vnn0+Lp+XappmlS0VnQDPiuWx2ccclWAXuiCQlCIhh0tZXbBc5bhJ0P3BpeKZcPX
# ZBXSK8sGTHzDEIufRgqERY41vfpeonZ31N2yuiDUoN0beqjTs5BeQskmAM/wmeg8
# hoxSLRVMY04lM/MHmlr6zbgAQg+fU1lQAj7EWCQWwjrrVgJU6P5Jfw4SZTTAp5Cw
# j7Q+s87DzgJIvf2kr0D+RMynE7M7qJx53rXsLM2LR4A5EwIow4QfjWa2JH1SIsdy
# tWIyjouU9djojBhjCSDnYYiMWDU2+0mgTAeSx0qtNNp8W5Mw7RWaHx/q/h++WzzV
# UnIAb4bDRTugECpUu1APAC1EymM4/EcChi8icMyKg9uucgFEG8c+ECBQZDS0RewZ
# Z4QfZ9WNH/w942ho7bIOvlHEsL/h9cI6vcInVH1Z7qkTMYu/Gxa49G4WmQW3i62b
# GJRgoE9MmGMY0X9Tu6h12Q9sEZN13Lz6Tu/3JqFE4TrCgDGCAs4wggLKAgEBMGkw
# UTEtMCsGA1UEAwwkSVJJUyBTdGF0aW9uIC0gU2lnbmF0dXJlIGRlcyBzY3JpcHRz
# MRMwEQYDVQQKDApBUkdPUyBSRElBMQswCQYDVQQGEwJNQQIUGZGS+gEtvWSk/BGf
# +u25JLv3Lm4wDQYJYIZIAWUDBAIBBQCggbcwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYJKoZIhvcNAQkFMQ8XDTI2MDkyNDAwMzk1MlowHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwLQYKKwYBBAGCNwIBDDEfMB2gG4EZSVJJUyAtIHNj
# cmlwdHMgZGUgc3RhdGlvbjAvBgkqhkiG9w0BCQQxIgQgfdEryPiob+n+lRS4U/qn
# r1LED9DHqs7RYNVqO+2cL1YwDQYJKoZIhvcNAQEBBQAEggGAQDGEZl1APQFGQjNO
# t79q/e5gUqhKGrlR9Iy+T8iX5oswVZO5glGLdi1AcT3uHnrB3vEbE9JGor7pbvpi
# 4OCbCerdKlyOO6ORUUk0SvWRgVjB0nviiG9CtHyc1voGEmIEIQKpVQ+/hqFd1fII
# zwewedxbAS1dvSr/m1Xh/dfRB/e08C1NauWHEZDgiSQSxBbCUgQA6SGdV8FPJdFW
# 3hX6nnp9joths880fOLBqVi27evchNMMCbXU003z2J6M96sDBCp27RWuLStcwZbD
# fGuarwb72INMuzRlsuQVJN7u0Wlgxh/VLX3639WJCXspy4Xfh7iRVs6nlFz9UO9f
# Rxm6XNAdKQOvvx9oyWzR54PuFfSu1aO5qaAoj0+pGnCm1O7Xwq9omcnlLgv1VmnX
# M7ZWjlDZxcsLQOR4VtVb4loNjR2ey2xlAF9KRTQgrPEWtFVyJu3FYDdi5n7LRF/Y
# Cam5VDF31GYSIEQVdYxlu3DeMShrhlNzVkTI/KcPihzg7epu
# SIG # End signature block
